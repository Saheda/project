<?php


mysql_connect('localhost','root','','repo') OR die(' :-) can not connect');