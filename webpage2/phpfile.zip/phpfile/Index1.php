
<!DOCTYPE html>
<html>
<head>
<title>
form
</title>

 <link href="css/bootstrap.min.css" rel="stylesheet"/>

<link href="sty.css" rel="stylesheet" type="text/css"/> 

</head>
<body>

<div class="container">
 
	<nav>
	 
	<div class="navbar-header">
	<a class="navbar-brand" href="ino.php">Sign In/ Register</a>
	</div>
	<div class="fulfil">
	<ul class="nav navbar-nav">
	<li><a href="Index1.php">Home</a>
    <li><a href="show.php">show</a></li>
        <li><a href="#">Services</a></li> 
        <li><a href="#">About Us</a></li> 
      </ul>
    </div>
 
</nav>
   
 </div>
 <div class="main"><img src="car1.jpg" height="300px" width="1100px"/></div>
 
  <div class="row">
  
    <div class="col-md-4"><h2>Why Choose us</h2>
      <p class="body">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
    </div>
    <div class="col-md-4"> <h2>Benefit for you</h2>
      <p class="body">Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
    </div>
    
     <div class="col-md-4"> 
	 <h2>Get auto repair</h2>
      <p class="body">Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
    </div>
    
    </div>
 <div class="footer">
 <div class="page-footer"><div class="col-md-4">
 <img src="car2.jpg" height="170px" width="350px"/> <h4>Taka/= 2,00000 only</h4></div>
<div class="col-md-4">
 <img src="car3.jpg" height="170px" width="350px"/> <h4>Taka/= 2,00000 only</h4></div><div class="col-md-4">
 <img src="car4.jpg" height="170px" width="350px"/> <h4>Taka/= 2,00000 only</h4> </div>
 
 
 
 
 
 <br/><br/>
 
 </div>

 <div class="page-footer1">
 <marque>Buy your chossable car in sesson because it take you discount. so click and buy</marque></div>
 </div>
 
</body>
</html>